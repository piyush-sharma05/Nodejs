<Setup>

This application uses Mongodb Atlas for database. To successfully run this application register on Atlas portal.
Create a cluster there and after that click on connect and use connection string from atlas and then change
connection string with password into "app.js".

Install "Mongodb for Vscode" extension then go to view>>command palette and add the connection string there to make a connection. 

<Backend>
1> Run "npm install" and "npm install -g nodemon".
2> Run nodemon "app.js" on terminal.

<Application runs on "http://localhost:3000" on browser.